<?php $__env->startSection('content'); ?>


    <?php echo $__env->make('prob-notice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="d-flex justify-content-end mb-3">
                    <a href="<?php echo e(route('prizes.create')); ?>" class="btn btn-info">Create</a>
                </div>
                <h1>Prizes</h1>
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Title</th>
                            <th>Probability</th>
                            <th>Awarded</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $prizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prize): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($prize->id); ?></td>
                                <td><?php echo e($prize->title); ?></td>
                                <td><?php echo e($prize->probability); ?></td>
                                <td><?php echo e($prize->awarded); ?></td>
                                <td>
                                    <div class="d-flex gap-2">
                                        <a href="<?php echo e(route('prizes.edit', [$prize->id])); ?>" class="btn btn-primary">Edit</a>
                                        <?php echo Form::open(['method' => 'DELETE', 'route' => ['prizes.destroy', $prize->id]]); ?>

                                        <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                                        <?php echo Form::close(); ?>

                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card">
                    <div class="card-header">
                        <h3>Simulate</h3>
                    </div>
                    <div class="card-body">
                        <?php echo Form::open(['method' => 'POST', 'route' => ['simulate']]); ?>

                        <div class="form-group">
                            <?php echo Form::label('number_of_prizes', 'Number of Prizes'); ?>

                            <?php echo Form::number('number_of_prizes', 50, ['class' => 'form-control']); ?>

                        </div>
                        <?php echo Form::submit('Simulate', ['class' => 'btn btn-primary']); ?>

                        <?php echo Form::close(); ?>

                    </div>

                    <br>

                    <div class="card-body">
                        <?php echo Form::open(['method' => 'POST', 'route' => ['reset']]); ?>

                        <?php echo Form::submit('Reset', ['class' => 'btn btn-primary']); ?>

                        <?php echo Form::close(); ?>

                    </div>

                </div>
            </div>
        </div>
    </div>


    <div class="container  mb-4">
        <div class="row">
            <div class="col-md-6">
                <h2>Probability Settings</h2>
                <canvas id="probabilityChart"></canvas>
            </div>
            <div class="col-md-6">
                <h2>Actual Rewards</h2>
                <canvas id="awardedChart"></canvas>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2"></script>
<script>var prizesData = <?php echo json_encode($prizes, 15, 512) ?>;</script>
<script src="<?php echo e(asset('js/probability_chart.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp8.1.25\htdocs\enacton\resources\views/prizes/index.blade.php ENDPATH**/ ?>