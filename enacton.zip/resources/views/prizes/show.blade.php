@extends('default')

@section('content')

	{{ $prize->id }}

@stop